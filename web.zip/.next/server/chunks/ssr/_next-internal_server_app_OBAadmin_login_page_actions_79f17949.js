module.exports=[76790,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_OBAadmin_login_page_actions_79f17949.js.map