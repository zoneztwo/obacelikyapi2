module.exports=[5411,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_OBAadmin_page_actions_e8c5a345.js.map