module.exports=[30612,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hakkimizda_page_actions_dc6d5489.js.map