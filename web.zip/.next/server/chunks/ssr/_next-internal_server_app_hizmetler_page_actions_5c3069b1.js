module.exports=[20345,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hizmetler_page_actions_5c3069b1.js.map