module.exports=[6529,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_iletisim_page_actions_25f51c87.js.map